var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__e7fc0b67._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_d02a8f19.js")
R.m(30450)
module.exports=R.m(30450).exports
