module.exports=[75e3,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_facilities_page_actions_941b307d.js.map