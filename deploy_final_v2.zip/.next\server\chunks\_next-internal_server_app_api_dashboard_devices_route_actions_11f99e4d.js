module.exports=[36152,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_devices_route_actions_11f99e4d.js.map