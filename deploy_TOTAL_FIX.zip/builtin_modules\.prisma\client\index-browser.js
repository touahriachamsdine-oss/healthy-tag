
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('@prisma/client/runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.WilayaScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  nameAr: 'nameAr',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.BaladiyaScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  nameAr: 'nameAr',
  wilayaId: 'wilayaId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FacilityScalarFieldEnum = {
  id: 'id',
  name: 'name',
  type: 'type',
  address: 'address',
  phone: 'phone',
  baladiyaId: 'baladiyaId',
  latitude: 'latitude',
  longitude: 'longitude',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.UserScalarFieldEnum = {
  id: 'id',
  email: 'email',
  password: 'password',
  firstName: 'firstName',
  lastName: 'lastName',
  phone: 'phone',
  role: 'role',
  isActive: 'isActive',
  twoFactorEnabled: 'twoFactorEnabled',
  twoFactorSecret: 'twoFactorSecret',
  wilayaId: 'wilayaId',
  baladiyaId: 'baladiyaId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  lastLoginAt: 'lastLoginAt'
};

exports.Prisma.SessionScalarFieldEnum = {
  id: 'id',
  userId: 'userId',
  token: 'token',
  expiresAt: 'expiresAt',
  createdAt: 'createdAt',
  userAgent: 'userAgent',
  ipAddress: 'ipAddress'
};

exports.Prisma.DeviceScalarFieldEnum = {
  id: 'id',
  deviceId: 'deviceId',
  simNumber: 'simNumber',
  apiKey: 'apiKey',
  type: 'type',
  model: 'model',
  firmwareVersion: 'firmwareVersion',
  facilityId: 'facilityId',
  wilayaId: 'wilayaId',
  baladiyaId: 'baladiyaId',
  latitude: 'latitude',
  longitude: 'longitude',
  targetTemp: 'targetTemp',
  tempMin: 'tempMin',
  tempMax: 'tempMax',
  humidityMin: 'humidityMin',
  humidityMax: 'humidityMax',
  alertDelayMinutes: 'alertDelayMinutes',
  needsManualReset: 'needsManualReset',
  healthStatus: 'healthStatus',
  isOnline: 'isOnline',
  lastSeenAt: 'lastSeenAt',
  lastTempValue: 'lastTempValue',
  lastHumidityValue: 'lastHumidityValue',
  lastLatitude: 'lastLatitude',
  lastLongitude: 'lastLongitude',
  installDate: 'installDate',
  lastMaintenanceDate: 'lastMaintenanceDate',
  nextMaintenanceDate: 'nextMaintenanceDate',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.DeviceReadingScalarFieldEnum = {
  id: 'id',
  deviceId: 'deviceId',
  temperature: 'temperature',
  humidity: 'humidity',
  latitude: 'latitude',
  longitude: 'longitude',
  gsmSignal: 'gsmSignal',
  batteryLevel: 'batteryLevel',
  healthStatus: 'healthStatus',
  deviceTimestamp: 'deviceTimestamp',
  serverTimestamp: 'serverTimestamp'
};

exports.Prisma.DeviceEventScalarFieldEnum = {
  id: 'id',
  deviceId: 'deviceId',
  eventType: 'eventType',
  description: 'description',
  metadata: 'metadata',
  timestamp: 'timestamp'
};

exports.Prisma.AlertScalarFieldEnum = {
  id: 'id',
  deviceId: 'deviceId',
  alertType: 'alertType',
  severity: 'severity',
  title: 'title',
  message: 'message',
  triggerValue: 'triggerValue',
  thresholdValue: 'thresholdValue',
  status: 'status',
  acknowledgedBy: 'acknowledgedBy',
  acknowledgedAt: 'acknowledgedAt',
  resolvedAt: 'resolvedAt',
  smsNotified: 'smsNotified',
  emailNotified: 'emailNotified',
  createdAt: 'createdAt'
};

exports.Prisma.AIAnalyticsScalarFieldEnum = {
  id: 'id',
  deviceId: 'deviceId',
  anomalyScore: 'anomalyScore',
  anomalyType: 'anomalyType',
  predictedFailure: 'predictedFailure',
  failureProbability: 'failureProbability',
  failureType: 'failureType',
  predictedTimeToFailure: 'predictedTimeToFailure',
  patternType: 'patternType',
  confidence: 'confidence',
  recommendation: 'recommendation',
  analyzedAt: 'analyzedAt'
};

exports.Prisma.AuditLogScalarFieldEnum = {
  id: 'id',
  userId: 'userId',
  action: 'action',
  entityType: 'entityType',
  entityId: 'entityId',
  oldValue: 'oldValue',
  newValue: 'newValue',
  ipAddress: 'ipAddress',
  userAgent: 'userAgent',
  timestamp: 'timestamp'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};
exports.FacilityType = exports.$Enums.FacilityType = {
  HOSPITAL: 'HOSPITAL',
  PHARMACY: 'PHARMACY',
  VACCINE_CENTER: 'VACCINE_CENTER',
  FOOD_STORAGE: 'FOOD_STORAGE',
  LABORATORY: 'LABORATORY',
  BLOOD_BANK: 'BLOOD_BANK',
  OTHER: 'OTHER'
};

exports.UserRole = exports.$Enums.UserRole = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  WILAYA_ADMIN: 'WILAYA_ADMIN',
  BALADIYA_ADMIN: 'BALADIYA_ADMIN'
};

exports.DeviceType = exports.$Enums.DeviceType = {
  FRIDGE: 'FRIDGE',
  FREEZER: 'FREEZER'
};

exports.HealthStatus = exports.$Enums.HealthStatus = {
  HEALTHY: 'HEALTHY',
  WARNING: 'WARNING',
  NOT_HEALTHY: 'NOT_HEALTHY',
  OFFLINE: 'OFFLINE',
  UNKNOWN: 'UNKNOWN'
};

exports.EventType = exports.$Enums.EventType = {
  POWER_ON: 'POWER_ON',
  POWER_OFF: 'POWER_OFF',
  NETWORK_CONNECTED: 'NETWORK_CONNECTED',
  NETWORK_DISCONNECTED: 'NETWORK_DISCONNECTED',
  GPS_LOCATION_CHANGED: 'GPS_LOCATION_CHANGED',
  CONFIG_UPDATED: 'CONFIG_UPDATED',
  FIRMWARE_UPDATED: 'FIRMWARE_UPDATED',
  MAINTENANCE_COMPLETED: 'MAINTENANCE_COMPLETED',
  SENSOR_FAILURE: 'SENSOR_FAILURE',
  DOOR_OPENED: 'DOOR_OPENED',
  DOOR_CLOSED: 'DOOR_CLOSED'
};

exports.AlertType = exports.$Enums.AlertType = {
  TEMPERATURE_HIGH: 'TEMPERATURE_HIGH',
  TEMPERATURE_LOW: 'TEMPERATURE_LOW',
  HUMIDITY_HIGH: 'HUMIDITY_HIGH',
  HUMIDITY_LOW: 'HUMIDITY_LOW',
  NO_SIGNAL: 'NO_SIGNAL',
  GPS_MOVED: 'GPS_MOVED',
  SENSOR_FAILURE: 'SENSOR_FAILURE',
  POWER_OUTAGE: 'POWER_OUTAGE',
  DOOR_OPEN_TOO_LONG: 'DOOR_OPEN_TOO_LONG',
  COMPRESSOR_ISSUE: 'COMPRESSOR_ISSUE'
};

exports.AlertSeverity = exports.$Enums.AlertSeverity = {
  LOW: 'LOW',
  MEDIUM: 'MEDIUM',
  HIGH: 'HIGH',
  CRITICAL: 'CRITICAL'
};

exports.AlertStatus = exports.$Enums.AlertStatus = {
  ACTIVE: 'ACTIVE',
  ACKNOWLEDGED: 'ACKNOWLEDGED',
  RESOLVED: 'RESOLVED',
  DISMISSED: 'DISMISSED'
};

exports.Prisma.ModelName = {
  Wilaya: 'Wilaya',
  Baladiya: 'Baladiya',
  Facility: 'Facility',
  User: 'User',
  Session: 'Session',
  Device: 'Device',
  DeviceReading: 'DeviceReading',
  DeviceEvent: 'DeviceEvent',
  Alert: 'Alert',
  AIAnalytics: 'AIAnalytics',
  AuditLog: 'AuditLog'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
