module.exports=[8631,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_map_route_actions_e6c4fc39.js.map