
const path = require('path');

// 1. Tell Node to find its brain in our custom folder
// This prevents the CloudLinux "node_modules" conflict
module.paths.push(path.join(__dirname, 'builtin_modules'));

// 2. Set Production mode
process.env.NODE_ENV = 'production';

// 3. Load the pre-compiled server
console.log('🚀 Final Launch Step: Starting Standalone Server...');
require('./.next/standalone/server.js');
