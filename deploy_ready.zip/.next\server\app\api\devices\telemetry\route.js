var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/devices/telemetry/route.js")
R.c("server/chunks/[root-of-the-server]__5ca315f9._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_devices_telemetry_route_actions_1b99971e.js")
R.m(26217)
module.exports=R.m(26217).exports
