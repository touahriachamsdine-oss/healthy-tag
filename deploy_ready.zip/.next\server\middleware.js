var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]_next_dist_f9e520a4._.js")
R.c("server/chunks/[root-of-the-server]__4898071c._.js")
R.m(89997)
module.exports=R.m(89997).exports
