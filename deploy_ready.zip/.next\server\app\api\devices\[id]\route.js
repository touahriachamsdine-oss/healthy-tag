var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/devices/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__d6e56d3e._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_devices_[id]_route_actions_627654f2.js")
R.m(10549)
module.exports=R.m(10549).exports
