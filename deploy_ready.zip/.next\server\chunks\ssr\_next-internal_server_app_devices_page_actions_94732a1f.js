module.exports=[20781,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_devices_page_actions_94732a1f.js.map