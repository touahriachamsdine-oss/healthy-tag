module.exports=[22559,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_devices_route_actions_8bc4086f.js.map