module.exports=[21321,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_devices_%5Bid%5D_readings_route_actions_4cfa5c7a.js.map