module.exports=[99101,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_history_route_actions_e4445da9.js.map