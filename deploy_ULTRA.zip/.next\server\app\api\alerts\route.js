var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/alerts/route.js")
R.c("server/chunks/[root-of-the-server]__908bf1ce._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_alerts_route_actions_b2cebd15.js")
R.m(15928)
module.exports=R.m(15928).exports
