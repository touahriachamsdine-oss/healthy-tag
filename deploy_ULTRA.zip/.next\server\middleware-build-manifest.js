globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c538e866a45e74bb.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/2d67c5fb9d2cf758.js",
    "static/chunks/dde2c8e6322d1671.js",
    "static/chunks/turbopack-3818948a395acc91.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];