module.exports=[80353,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_sensors_page_actions_db99c97c.js.map