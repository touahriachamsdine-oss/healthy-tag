var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/devices/route.js")
R.c("server/chunks/[root-of-the-server]__ceeeefa1._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_devices_route_actions_8bc4086f.js")
R.m(43804)
module.exports=R.m(43804).exports
