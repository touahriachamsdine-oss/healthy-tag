module.exports=[24485,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_alerts_route_actions_b2cebd15.js.map