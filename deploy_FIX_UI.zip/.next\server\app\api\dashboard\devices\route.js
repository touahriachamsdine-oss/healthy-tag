var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/devices/route.js")
R.c("server/chunks/[root-of-the-server]__00ba822b._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_devices_route_actions_11f99e4d.js")
R.m(90880)
module.exports=R.m(90880).exports
