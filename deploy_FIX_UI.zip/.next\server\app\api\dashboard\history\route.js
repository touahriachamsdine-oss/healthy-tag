var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/history/route.js")
R.c("server/chunks/[root-of-the-server]__1566ca47._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__48f36a33._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_history_route_actions_e4445da9.js")
R.m(70568)
module.exports=R.m(70568).exports
