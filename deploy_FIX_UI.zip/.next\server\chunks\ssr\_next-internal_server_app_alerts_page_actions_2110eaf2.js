module.exports=[97253,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_alerts_page_actions_2110eaf2.js.map